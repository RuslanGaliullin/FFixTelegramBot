# FFixTelegramBot
Course Project by Vasilev Vladislav and Galiullin Ruslan
